
import pandas as pd

def calculate_ev(prizepicks_df, odds_df, projection_source="sharp"):
    prizepicks_df['PlayerLower'] = prizepicks_df['Player'].str.lower().str.replace(".", "").str.strip()
    odds_df['TeamLower'] = odds_df['Team'].str.lower().str.strip()

    odds_df['ProjProb'] = odds_df['ImpliedProb']
    merged_df = pd.merge(prizepicks_df, odds_df, left_on='Team', right_on='Team', how='inner')

    payout_multiplier = 3.0
    merged_df['EV'] = (merged_df['ProjProb'] * payout_multiplier) - (1 - merged_df['ProjProb'])
    merged_df['Edge'] = merged_df['ProjProb'] - merged_df['ImpliedProb']

    return merged_df[[
        'Player', 'Stat', 'Line', 'Team', 'Sport',
        'Odds', 'ImpliedProb', 'ProjProb', 'EV', 'Edge', 'Bookmaker'
    ]].sort_values(by='EV', ascending=False)
