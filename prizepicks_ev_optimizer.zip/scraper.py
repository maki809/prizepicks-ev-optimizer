
import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import undetected_chromedriver as uc

def scrape_prizepicks(sport="nba", num_scrolls=5):
    url = f"https://app.prizepicks.com/entries"

    options = uc.ChromeOptions()
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")

    driver = uc.Chrome(options=options)
    driver.get(url)
    time.sleep(3)

    body = driver.find_element(By.TAG_NAME, "body")
    for _ in range(num_scrolls):
        body.send_keys(Keys.END)
        time.sleep(1)

    elements = driver.find_elements(By.CLASS_NAME, "projection-picks__player")
    props = []
    for el in elements:
        try:
            player = el.find_element(By.CLASS_NAME, "name").text
            stat = el.find_element(By.CLASS_NAME, "stat").text
            line = el.find_element(By.CLASS_NAME, "line").text
            team = el.find_element(By.CLASS_NAME, "team").text
            props.append({
                "Player": player,
                "Stat": stat,
                "Line": float(line),
                "Team": team,
                "Sport": sport
            })
        except:
            continue

    driver.quit()
    return pd.DataFrame(props)
